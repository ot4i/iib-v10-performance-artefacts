-- SQL for tuning tables when running on larger machines and running scaling tests.

connect to USERDB

update db cfg for USERDB using logprimary 10
update db cfg for USERDB using logfilsiz 250000
update db cfg for USERDB using logbufsz 4096

-- Reset any database connection context there may
connect reset

terminate
